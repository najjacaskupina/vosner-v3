<?php
include 'conn.php';
if(isset($_POST['key'])){
    $token = $_POST['tokenUcenca'];
    $idp=$_POST['idPredmeta'];
    if($_POST['key']=="vpis"){
        
        $sql = "select * from ucenci where token = '$token'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result);
        if($row == null){
            exit("Wrong token");
        }else{
            $id = $row['id'];
            $sql = "insert into ucenecpredmet (idUcenec, idPredmet) values ('$id', '$idp')";
            $result = mysqli_query($conn, $sql);
        }
    }
    if($_POST['key']=="izpis"){
        $sql = "select * from ucenci where token = '$token'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result);
        $id = $row['id'];
        $sql = "DELETE FROM ucenecpredmet WHERE idUcenec = '$id' and idPredmet = '$idp';";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result);
        if($row == null){
            exit("Wrong token");
        }else{
            exit(json_encode($result));
            
        }
    }
}
    
?>