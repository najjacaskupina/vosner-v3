<?php
session_start();
$token=$_SESSION['token'];
if (!isset($_SESSION['token'])) {
  header("Location: index.php");
}
$sql = "select * from ucenci where token = '$token'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result);
$id = $row['id'];
$email = $row['email'];
$ime = $row['ime'];
$priimek = $row['priimek'];
$dir = "naloge/".$id;
if(is_dir("server")){

           if(is_dir($dir) === false )
            {
                mkdir($dir, 0777);
            }
          }
/*
echo "token €tokenid = id uporabnika+čas v unix <br>";
echo "token trenutne seje: €token = openssl_encrypt(€tokenId, €cypherMethod, €key, €options=0, €iv); <br></blockquote>";
echo $token;
*/
?>