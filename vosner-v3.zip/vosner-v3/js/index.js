function registracija(){
    //console.log("registracija");
    procedures("reg");
}
function prijava(){
    //console.log("prijava");
    procedures("log");
}
function prijavaPoRegistraciji(){
    $.ajax({
        url: 'server/login.php',
        method: 'POST',
        dataType: 'text',
        data:{
            key: "log",
            email: mail,
            password: geslo}, 
        success: function(response){
            if (response != "err") {
                console.log(response);
            }else{
                console.log("napačni podatki");
            }
        }
    })
}
function prijavaUcitelj(){
    procedures("logU");
}
function procedures(val){
    getParams(val);
    ajaxFunctions(val);
}
function getParams(val){
    if(val == "reg"){
        mail = document.getElementById('registracija-mail').value;
        geslo = document.getElementById('registracija-geslo').value;
    }
    if(val == "log"){
        mail = document.getElementById('login-mail').value;
        geslo = document.getElementById('login-geslo').value;
    }
    if(val == "logU"){
        mail = document.getElementById('loginU-mail').value;
        geslo = document.getElementById('loginU-geslo').value;
    }
    if(ValidateEmail(mail) && ValidatePassword(geslo)){
        //console.log(mail);
        //console.log(geslo);
    }else{
        mail = "";
        geslo = "";
    }
    
}
function ValidateEmail(mail){
    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)){
        return (true)
    }
    return (false)
}
function ValidatePassword(password){
    if (password.length >=5){
        return (true)
    }
    return (false)
}
function validateReg(){
    console.log("a");
    mail = document.getElementById('registracija-mail').value;
    geslo = document.getElementById('registracija-geslo').value;
    if (ValidatePassword(geslo) == true && ValidateEmail(mail) == true) {
        console.log("enabling");
        document.getElementById('regBtn').disabled = false;
    }
}
function validatePrijava(){
    console.log("a");
    mail = document.getElementById('prijava-mail').value;
    geslo = document.getElementById('prijava-geslo').value;
    if (ValidatePassword(geslo) == true && ValidateEmail(mail) == true) {
        console.log("enabling");
        document.getElementById('loginBtn').disabled = false;
    }
}