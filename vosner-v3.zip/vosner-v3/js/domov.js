function main(){
    console.log(checkToken());
    console.log(getCookie("token"));
    chkTKN();
    mojiPredmeti();
}
function visit(predmet){
    window.location = "predmet.php?id="+predmet;
}
function fillData(response){
    document.getElementById('ime').innerHTML = response['ime'];
    document.getElementById('priimek').innerHTML = response['priimek'];
    document.getElementById('email').innerHTML = response['email'];
}
function mojiPredmeti(){
    $.ajax({
        url: 'server/getData.php',
        method: 'POST',
        dataType: 'json',
        data:{
            key: "mojiPredmeti",
            token: sessionStorage.getItem('token')}, 
            success: function(response){
                console.log(response);
            }
        })
}