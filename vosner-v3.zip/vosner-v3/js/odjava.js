function odjava(){
    setCookie('token', "tken");
}