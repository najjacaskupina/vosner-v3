<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    include 'server/conn.php';
    include 'server/session.php';
    ?>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/uredi-profil.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        function main(){
            fillData();
        }
        tokenFromDB = "";
function fillData(){
    document.getElementById('ime').setAttribute('value', "<?php echo $row['ime']; ?>");
    document.getElementById('priimek').setAttribute('value', "<?php echo $row['priimek']; ?>");
    document.getElementById('email').setAttribute('value', "<?php echo $row['email']; ?>");
}
function uredi(){
    console.log("urejam");
    token = "<?php echo $token; ?>";
    ime = document.getElementById('ime').value;
    priimek = document.getElementById('priimek').value;
    email = document.getElementById('email').value;
    console.log(ime + priimek + email + geslo);
    if (tokenFromDB == token) {
        if (document.getElementById('geslo').value != "") {
            geslo = document.getElementById('geslo').value;
            $.ajax({
                url: 'server/updateData.php',
                method: 'POST',
                dataType: 'text',
                data:{
                    key: "updPsw",
                    password: geslo,
                    token: "<?php echo $token; ?>"}, 
                    success: function(response){console.log(response);}
            })
        }$.ajax({
            url: 'server/updateData.php',
            method: 'POST',
            dataType: 'text',
            data:{
                key: "updData",
                ime: ime,
                priimek: priimek,
                email: email,
                token: "<?php echo $token; ?>"}, 
                success: function(response){console.log(response);
                if (response == "Success on updating user") {
                    window.location = 'domov.php';
                }}
        })
    }
}
    </script>
</head>
<body onload="main()">
    <div class="container">
        <main>
            <form action="server/updateData.php" method="post">
            <div class="profile-container">
                <img class="profile-image" src="images/profil.png" alt="ocene">
                <div class="profile-data">
                    <div>Ime: <input id="ime" name="ime"></input> </div>
                    <div>Priimek: <input id="priimek" name="priimek"></input> </div>
                    <div>E-mail: <input id="email" name="email"></input> </div>
                    <input type="hidden" name="key" value="updData">
                    <input type="hidden" name="token" value='"<?php echo $token; ?>"'>
                </div>
                
                <div class="profile-data">
                    <div></div>
                    <div>Geslo: <input type="password" id="geslo" name="password"></input></div>
                    <div></div>
                </div>
                <div class="profile-data-edit">
                    <input type="submit" class="urediBtn" onclick="uredi()" value="Potrdi">
                    </form>
                </div>
            </div>
        </main>
      </div>
</body>
</html>