<?php
include 'server/conn.php';
include 'server/session.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Predmet</title>
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/predmet.css">
    <link rel="stylesheet" href="css/table.scss">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
      function pokaziNalogo(id1){
        document.getElementById('oddajNalogo').style.display = 'block';
        document.getElementById('narejeno').style.display = 'none';
        document.getElementById('formaNal').style.display = 'block';
        
        $.ajax({
        url: 'server/getData.php',
        method: 'POST',
        dataType: 'json',
        data:{
            key: "naloga",
            id: id1}, 
            success: function(response){
                console.log(response);
                document.getElementById('imeNaloge').innerHTML = response['ime'];
                document.getElementById('datumObjave').innerHTML = response['datumObjave'];
                document.getElementById('datumPoteka').innerHTML = response['datumPoteka'];
                document.getElementById('navodila').href = response['navodila'];
                document.getElementById('idNaloge').value = id1;
                
            }
            
        })
        $.ajax({
        url: 'server/getData.php',
        method: 'POST',
        dataType: 'text',
        data:{
            key: "oddanaNaloga",
            id: <?php echo $row['id']; ?>,
            idNal: id1}, 
            success: function(response){
                console.log(response);
                if(response =="Opravil"){
                  document.getElementById('formaNal').style.display = 'none';
                  document.getElementById('narejeno').style.display = 'block';
                }
            }
            
        })
      }
      function closeTab(){
        document.getElementById('oddajNalogo').style.display = 'none';
      }
      function vpis(id){
        $.ajax({
        url: 'server/vpisIzpis.php',
        method: 'POST',
        dataType: 'text',
        data:{
            key: "vpis",
            tokenUcenca: "<?php echo $token; ?>",
            idPredmeta: id}, 
            success: function(response){
                window.location = "predmet.php?id="+id;
            }
        })
      }
      function izpis(id){
        $.ajax({
        url: 'server/vpisIzpis.php',
        method: 'POST',
        dataType: 'text',
        data:{
            key: "izpis",
            tokenUcenca: "<?php echo $token; ?>",
            idPredmeta: id}, 
            success: function(response){
                window.location = "predmet.php?id="+id;
            }
        })
      }
    </script>
    
</head>
<body>
    
<?php
    $idPredmeta = $_GET['id'];
    $sql = "select * from predmeti where idPredmeta = '$idPredmeta'";
              $result = mysqli_query($conn, $sql);
              $row = mysqli_fetch_array($result);
    ?>
        <div class="container">
        <div id="oddajNalogo">
            <span class="x" onclick="closeTab()">X</span>
            <h2 id="imeNaloge">Ime naloge</h2>
            <span  class="navodila">Navodila: <a id="navodila" href="" download>Navodila</a></span>
            <span class="do">Datum objave: <span id="datumObjave"></span></span>
            <span class="dp">Datum poteka: <span id="datumPoteka"></span></span>
            <form id="formaNal" action="server/posljiNalogo.php" method="post" enctype="multipart/form-data">
              <div class="fileUpl">
              <label for="upload"> Your file:</label>
              <input type="file" name="file"></div>
              <input id="idNaloge" type="hidden" name="idNaloge">
              <input class="oddajBtn aniBtn" type="submit" value="Oddaj">
            </form>
            <span id="narejeno">Oddano</span>
        </div>
        <aside class="sidebar" data-sidebar>
          <div class="top-sidebar">
            <div class="eucilnica">E-učilnica</div>
          </div>
          <div class="middle-sidebar">
            <ul class="sidebar-list">
              <li class="sidebar-list-item">
                <a href="domov.php" class="sidebar-link">
                  <img class="sidebar-icon" src="images/profil.png" alt="ocene">
                  <div class="sidebar-text">Moj profil</div>
                </a>
              </li>
              <li class="sidebar-list-item active">
                <a href="vsiPredmeti.php" class="sidebar-link">
                  <img class="sidebar-icon" src="images/predmeti.png" alt="ocene">
                  <div class="sidebar-text">Predmeti</div>
                </a>
              </li>
              <li class="sidebar-list-item">
                <a href="ocene.php" class="sidebar-link">
                  <img class="sidebar-icon" src="images/ocene.png" alt="ocene">
                  <div class="sidebar-text">Ocene</div>
                </a>
              </li>
              <li class="sidebar-list-item">
                <a href="vseNaloge.php" class="sidebar-link">
                  <img class="sidebar-icon" src="images/vaje.png" alt="ocene">
                  <div class="sidebar-text">Naloge</div>
                </a>
              </li>
              <li class="sidebar-list-item">
                <a href="server/odjava.php" class="sidebar-link">
                  <img class="sidebar-icon" src="images/logout.png" alt="ocene">
                  <div class="sidebar-text">Odjava</div>
                </a>
              </li>
            </ul>
          </div>
          <div class="bottom-sidebar">
            <ul class="sidebar-list">
                <li class="sidebar-list-item">
                    <a href="vaje.php" class="sidebar-link">
                      <img class="sidebar-icon" src="images/nastvitve.png" alt="ocene">
                      <div class="sidebar-text">Nastavitve</div>
                    </a>
                  </li>
                  <li class="sidebar-list-item">
                    <a href="vaje.php" class="sidebar-link">
                      <img class="sidebar-icon" src="images/bug.png" alt="ocene">
                      <div class="sidebar-text">Bugi</div>
                    </a>
                  </li>
            </ul>
          </div>
        </aside>
        <main>
            <div class="profile-container">
                <h2><?php
                echo $row['imePredmeta'];
                ?></h2>
                <br><br>
                <img class="profile-image" src="images/profil.png" alt="ocene">
                <div class="profile-data">
                <div></div>
                    <div>Učitelj: <span><?php
                $sql = "select * from uciteljpredmet, ucitelji where idPredmeta = '$idPredmeta' and uciteljpredmet.idUcitelja = ucitelji.idUcitelja";
              $result = mysqli_query($conn, $sql);
              $row = mysqli_fetch_array($result);
              if($row == null){
                echo 'Ta predmet nima ucitelja';
            }else {
              echo $row['ime'] . " " . $row['priimek'];
            }
              
    ?></span> </div>
    <div></div>
                </div>

                <div class="profile-data-edit">
                  <?php
                    $sql = "select * from ucenecPredmet where idpredmet = '$idPredmeta' and idUcenec = '$id'";
                    $result = mysqli_query($conn, $sql);
                    $row = mysqli_fetch_array($result);
                    $prijavljen = false;
                    if($row == null){
                      echo '<button class="urediBtn aniBtn" onclick="vpis('.$idPredmeta.')">Vpis</button>';
                  }else {
                    $prijavljen = true;
                    echo '<button class="urediBtn aniBtn red" onclick="izpis('.$idPredmeta.')">Izpis</button>';
                  }
                  ?>
                    
                </div>
            </div>
        <div class="predmeti-container">
        <?php
        if ($prijavljen == true) {
          ?>
        <div class="table">
		<div class="table-header">
			<div class="header__item">Ime naloge</div>
            <div class="header__item">Datum objave</div>
            <div class="header__item">Datum poteka</div>
		</div>
		<div class="table-content">	
        <?php
              $sql = "select * from naloga_predmet where token = '$token' and idPredmeta = '$idPredmeta'";
              $result = mysqli_query($conn, $sql);
              while($row = mysqli_fetch_array($result)){
                echo '<div class="table-row pointer" onclick="pokaziNalogo('.$row['id'].')"><div class="table-data"><a>'.$row['ime'].'</a></div>';
                echo '<div class="table-data">'.$row['datumObjave'].'</div>
				<div class="table-data">'.$row['datumPoteka'].'</div></div>';
              }
            }
              ?>
					
		</div>	
	</div>
        </div>
        </main>
      </div>
</body>
</html>