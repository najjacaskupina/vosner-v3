-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Gostitelj: 127.0.0.1
-- Čas nastanka: 25. okt 2022 ob 08.48
-- Različica strežnika: 10.4.24-MariaDB
-- Različica PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Zbirka podatkov: `eucilnica`
--

-- --------------------------------------------------------

--
-- Nadomestna struktura pogleda `naloga_predmet`
-- (Oglejte si spodaj za resnični pogled)
--
CREATE TABLE `naloga_predmet` (
`id` int(11)
,`ime` varchar(30)
,`navodila` varchar(50)
,`datumObjave` timestamp
,`datumPoteka` datetime
,`idPredmeta` int(11)
,`token` varchar(300)
);

-- --------------------------------------------------------

--
-- Struktura tabele `naloge`
--

CREATE TABLE `naloge` (
  `id` int(11) NOT NULL,
  `ime` varchar(30) NOT NULL,
  `navodila` varchar(50) NOT NULL,
  `datumObjave` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `datumPoteka` datetime NOT NULL,
  `idPredmeta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `naloge`
--

INSERT INTO `naloge` (`id`, `ime`, `navodila`, `datumObjave`, `datumPoteka`, `idPredmeta`) VALUES
(1, 'Prva naloga predmet 1', '', '2022-09-27 17:13:01', '2022-09-27 19:12:32', 1),
(2, 'Druga naloga predmet 1', '', '2022-09-27 17:13:01', '2022-09-27 19:12:32', 1);

-- --------------------------------------------------------

--
-- Struktura tabele `oddanenaloge`
--

CREATE TABLE `oddanenaloge` (
  `id` int(11) NOT NULL,
  `idNaloge` int(11) NOT NULL,
  `idUcenca` int(11) NOT NULL,
  `pot` varchar(130) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `oddanenaloge`
--

INSERT INTO `oddanenaloge` (`id`, `idNaloge`, `idUcenca`, `pot`) VALUES
(3, 1, 5, '5/1-Pika-Poka-bitnami.css');

-- --------------------------------------------------------

--
-- Struktura tabele `predmeti`
--

CREATE TABLE `predmeti` (
  `idPredmeta` int(11) NOT NULL,
  `imePredmeta` varchar(30) NOT NULL,
  `letnik` int(1) NOT NULL,
  `okrajsava` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `predmeti`
--

INSERT INTO `predmeti` (`idPredmeta`, `imePredmeta`, `letnik`, `okrajsava`) VALUES
(1, 'Matematika', 1, 'MAT'),
(2, 'Slovenscina', 1, 'SLO'),
(3, 'Anglescina', 1, 'ANG'),
(4, 'Racunalnistvo', 1, 'RAC'),
(7, 'Matematika', 2, 'MAT'),
(8, 'Racunalnistvo', 2, 'RAC'),
(9, 'Anglescina', 2, 'ANG'),
(10, 'Sportna', 1, 'SPO'),
(11, 'Fizika', 1, 'FIZ'),
(12, 'Slovenscina', 2, 'SLO'),
(14, 'Fizika', 2, 'FIZ'),
(15, 'Sportna', 2, 'SPO'),
(16, 'Anglescina', 3, 'ANG'),
(17, 'Slovenscina', 3, 'SLO'),
(18, 'Matematika', 3, 'MAT'),
(19, 'Programiranje', 3, 'PRO'),
(20, 'Podatkovne baze', 3, 'UPN'),
(21, 'Racunalnisko oblikovanje', 3, 'ROB'),
(22, 'Anglescina', 4, 'ANG'),
(23, 'Matematika', 4, 'MAT'),
(24, 'Slovenscina', 4, 'SLO'),
(25, 'Razvoj spletnih aplikacij', 4, 'NRS'),
(26, 'Racunalniski praktikum', 4, 'RPR'),
(27, 'Podatkovne baze', 4, 'UPN');

-- --------------------------------------------------------

--
-- Struktura tabele `ucenci`
--

CREATE TABLE `ucenci` (
  `id` int(11) NOT NULL,
  `ime` varchar(20) NOT NULL,
  `priimek` varchar(20) NOT NULL,
  `datumPridruzitve` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `datumPrijave` datetime NOT NULL,
  `geslo` varchar(150) NOT NULL,
  `token` varchar(300) NOT NULL,
  `email` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `ucenci`
--

INSERT INTO `ucenci` (`id`, `ime`, `priimek`, `datumPridruzitve`, `datumPrijave`, `geslo`, `token`, `email`) VALUES
(0, 'Nik', 'ColnariÄ', '2022-10-25 06:44:43', '0000-00-00 00:00:00', '$2y$10$JDxncZEXaVnzG7tYM2pSf.TcwTuEwp9BbRMXIg/dlHkn6GM8.E.OC', 'MJfFBjDqbu9+V4NJ7O+7eQ==', 'nik.colnaricnc@gmail.com'),
(0, 'Steven', 'Freeman', '2022-10-25 06:44:43', '0000-00-00 00:00:00', '$2y$10$YPn5rX/a1g8mRHWEzAbis.fDsuKd014/l8hfw2bVU7m8tK7yAMoLG', 'MJfFBjDqbu9+V4NJ7O+7eQ==', 'sf@gmail.com'),
(0, 'Koza', 'Koza', '2022-10-25 06:44:43', '0000-00-00 00:00:00', '$2y$10$PWIfdmV84sliDB0C3U.X1e2QbLGZaxW0wVN7zLhwZyevGIX0cTIiS', 'MJfFBjDqbu9+V4NJ7O+7eQ==', 'amadejlupse@gmail.com'),
(0, 'Koza', 'Koza', '2022-10-25 06:44:43', '0000-00-00 00:00:00', '$2y$10$7gD8W9KHiyXfFDa4n28DyOGOmINajLkIva.pM98a5jJqYlyaQLqty', 'MJfFBjDqbu9+V4NJ7O+7eQ==', 'amadejlupse5@gmail.com');

-- --------------------------------------------------------

--
-- Struktura tabele `ucenecpredmet`
--

CREATE TABLE `ucenecpredmet` (
  `idUcenecPredmet` int(11) NOT NULL,
  `idUcenec` int(11) NOT NULL,
  `idPredmet` int(11) NOT NULL,
  `datumPridruzitve` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `ucenecpredmet`
--

INSERT INTO `ucenecpredmet` (`idUcenecPredmet`, `idUcenec`, `idPredmet`, `datumPridruzitve`) VALUES
(2, 1, 2, '2022-09-29 17:41:24'),
(3, 1, 3, '2022-09-29 17:41:27'),
(4, 1, 4, '2022-09-29 17:41:32'),
(9, 1, 8, '2022-09-29 20:20:57'),
(10, 1, 7, '2022-09-29 20:22:10'),
(12, 1, 1, '2022-09-29 22:00:01'),
(14, 5, 1, '2022-09-29 22:39:14'),
(0, 0, 9, '2022-10-18 05:29:22');

-- --------------------------------------------------------

--
-- Struktura tabele `ucitelji`
--

CREATE TABLE `ucitelji` (
  `idUcitelja` int(11) NOT NULL,
  `ime` varchar(30) NOT NULL,
  `priimek` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `geslo` varchar(100) NOT NULL,
  `token` varchar(300) NOT NULL,
  `datumPrijave` datetime NOT NULL,
  `datumPridruzitve` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `ucitelji`
--

INSERT INTO `ucitelji` (`idUcitelja`, `ime`, `priimek`, `email`, `geslo`, `token`, `datumPrijave`, `datumPridruzitve`) VALUES
(1, 'Bojan', 'Herman', 'bojan.herman@sc-celje.si', 'krompir123', '', '2022-10-25 08:21:54', '2022-10-25 06:23:37'),
(2, 'Andreja', 'Tkalec', 'andreja.tkalec@sc-celje.si', 'knjige123', '', '2022-10-25 08:21:54', '2022-10-25 06:23:37');

-- --------------------------------------------------------

--
-- Struktura tabele `uciteljpredmet`
--

CREATE TABLE `uciteljpredmet` (
  `idUciteljPredmet` int(11) NOT NULL,
  `idUcitelja` int(11) NOT NULL,
  `idPredmeta` int(11) NOT NULL,
  `datum` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Odloži podatke za tabelo `uciteljpredmet`
--

INSERT INTO `uciteljpredmet` (`idUciteljPredmet`, `idUcitelja`, `idPredmeta`, `datum`) VALUES
(1, 1, 11, '2022-10-25 06:26:43'),
(2, 2, 2, '2022-10-25 06:26:43'),
(3, 2, 12, '2022-10-25 06:32:19'),
(4, 2, 17, '2022-10-25 06:32:19'),
(5, 1, 14, '2022-10-25 06:32:50'),
(6, 2, 24, '2022-10-25 06:32:50');

-- --------------------------------------------------------

--
-- Struktura pogleda `naloga_predmet`
--
DROP TABLE IF EXISTS `naloga_predmet`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `naloga_predmet`  AS SELECT `naloge`.`id` AS `id`, `naloge`.`ime` AS `ime`, `naloge`.`navodila` AS `navodila`, `naloge`.`datumObjave` AS `datumObjave`, `naloge`.`datumPoteka` AS `datumPoteka`, `naloge`.`idPredmeta` AS `idPredmeta`, `ucenci`.`token` AS `token` FROM (((`naloge` join `predmeti` on(`naloge`.`idPredmeta` = `predmeti`.`idPredmeta`)) join `ucenecpredmet` on(`ucenecpredmet`.`idPredmet` = `predmeti`.`idPredmeta`)) join `ucenci` on(`ucenecpredmet`.`idUcenec` = `ucenci`.`id`))  ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
